# maxipago-prestashop
Prestashop Module for maxiPago!
# maxiPago payment method module for Prestashop.
Payment method module  (v0.1.0) - Prestashop 1.6.x


**[maxiPago!](http://www.maxipago.com/maxipago/)** 

With this module you'll be able to:
 - Make payments using **maxiPago!** Credit Card, Boleto and TEF (Electronic funds transfer)
 - Update yours orders by cron when there's any change at maxiPago!
 - Automatically chargeback when an order is cancelled
 - Automatically create the invoice if an order is approved
 - Print the "Boleto" to send with your order.
 

## Installation

### Manual:

- Download the [latest version](https://github.com/contardi/maxipago-prestashop/archive/master.zip) of the module.
- Unzip the file, copy and paste into yout Prestashop modules folder.
- Clear the Cache.
- Fill your credentials and enable the module

